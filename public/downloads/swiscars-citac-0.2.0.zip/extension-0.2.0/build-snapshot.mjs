// Writes snapshot.js from the reader's own snapshotScript, so the extension and the
// local reader read the page with exactly the same code. Run: node reader-extension/build-snapshot.mjs
import {writeFile} from 'node:fs/promises';
import {snapshotScript} from '../cloud-reader-runtime.mjs';
const out = new URL('./snapshot.js', import.meta.url);
await writeFile(out, '// GENERATED from cloud-reader-runtime.mjs snapshotScript — do not edit by hand.\nexport const snapshotScript = ' + snapshotScript.toString() + ';\n');
console.log('wrote', out.pathname);
